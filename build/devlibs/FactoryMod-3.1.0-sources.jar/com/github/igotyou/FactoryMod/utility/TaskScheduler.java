package com.github.igotyou.FactoryMod.utility;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TaskScheduler {
    private static final List<ScheduledTask> tasks = new ArrayList<>();
    private static int nextTaskId = 0;

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tick();
        });
    }

    private static void tick() {
        Iterator<ScheduledTask> iterator = tasks.iterator();
        while (iterator.hasNext()) {
            ScheduledTask task = iterator.next();
            if (task.cancelled) {
                iterator.remove();
                continue;
            }
            if (task.ticksRemaining <= 0) {
                try {
                    task.runnable.run();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                iterator.remove();
            } else {
                task.ticksRemaining--;
            }
        }
    }

    public static int scheduleSyncDelayedTask(Runnable runnable, int delayTicks) {
        ScheduledTask task = new ScheduledTask(runnable, delayTicks, nextTaskId++);
        tasks.add(task);
        return task.id;
    }
    
    public static void cancelTask(int id) {
        for (ScheduledTask task : tasks) {
            if (task.id == id) {
                task.cancelled = true;
                break;
            }
        }
    }

    private static class ScheduledTask {
        Runnable runnable;
        int ticksRemaining;
        int id;
        boolean cancelled;

        ScheduledTask(Runnable runnable, int ticksRemaining, int id) {
            this.runnable = runnable;
            this.ticksRemaining = ticksRemaining;
            this.id = id;
            this.cancelled = false;
        }
    }
}
