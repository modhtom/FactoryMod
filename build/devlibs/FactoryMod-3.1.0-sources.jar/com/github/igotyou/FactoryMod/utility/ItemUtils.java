package com.github.igotyou.FactoryMod.utility;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Arrays;

public class ItemUtils {

    public static void setLore(ItemStack is, String... lore) {
        List<Text> textList = Arrays.stream(lore).map(Text::literal).collect(Collectors.toList());
        is.set(DataComponentTypes.LORE, new LoreComponent(textList));
    }

    public static void addLore(ItemStack is, String... lore) {
        List<Text> currentLore = new ArrayList<>();
        LoreComponent existing = is.get(DataComponentTypes.LORE);
        if (existing != null) {
            currentLore.addAll(existing.lines());
        }
        for (String line : lore) {
            currentLore.add(Text.literal(line));
        }
        is.set(DataComponentTypes.LORE, new LoreComponent(currentLore));
    }

    public static void setDisplayName(ItemStack is, String name) {
        is.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name));
    }

    public static String getDisplayName(ItemStack is) {
        Text name = is.get(DataComponentTypes.CUSTOM_NAME);
        if (name != null) return name.getString();
        return is.getName().getString();
    }

    public static String getItemName(ItemStack is) {
        return getDisplayName(is);
    }
    
    public static String getItemName(Item is) {
        return is.getName().getString();
    }

    public static boolean isValidItem(ItemStack is) {
        return is != null && !is.isEmpty();
    }
}
