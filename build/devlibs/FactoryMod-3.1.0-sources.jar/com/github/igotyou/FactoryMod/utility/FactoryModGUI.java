package com.github.igotyou.FactoryMod.utility;

import com.github.igotyou.FactoryMod.FactoryModManager;
import com.github.igotyou.FactoryMod.factories.Factory;
import com.github.igotyou.FactoryMod.recipes.IRecipe;
import eu.pb4.sgui.api.gui.SimpleGui;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.List;

public class FactoryModGUI {
    private final FactoryModManager manager;

    public FactoryModGUI(FactoryModManager manager) {
        this.manager = manager;
    }

    public void showFactoryOverview(ServerPlayerEntity player) {
        SimpleGui gui = new SimpleGui(ScreenHandlerType.GENERIC_9X6, player, false);
        gui.setTitle(Text.literal("Factory Overview"));
        
        List<Factory> factories = manager.getAllFactories().stream().toList();
        for (int i = 0; i < factories.size(); i++) {
            Factory f = factories.get(i);
            // Just basic listing
            gui.setSlot(i, new net.minecraft.item.ItemStack(net.minecraft.item.Items.CRAFTING_TABLE), (index, type, action, gui1) -> {
                // Do something
            });
        }
        gui.open();
    }

    public void showFactoryMenu(ServerPlayerEntity player, Factory factory) {
        SimpleGui gui = new SimpleGui(ScreenHandlerType.GENERIC_9X3, player, false);
        gui.setTitle(Text.literal(factory.getName()));
        
        // This menu lets the player interact with the factory
        // E.g. view recipes, activate/deactivate
        // Just stub for now.
        gui.open();
    }
}
