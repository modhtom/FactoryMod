package com.github.igotyou.FactoryMod.utility;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.PersistentState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.registry.RegistryWrapper;

public class FactoryModSavedData extends PersistentState {

    public FactoryModSavedData() {}

    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        return nbt;
    }
}
