package com.github.igotyou.FactoryMod.interactionManager;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public interface IInteractionManager {
    void leftClick(ServerPlayerEntity p, BlockPos b, BlockState state, Direction face);
    void rightClick(ServerPlayerEntity p, BlockPos b, BlockState state, Direction face);
    void blockBreak(ServerPlayerEntity p, BlockPos b);
    void redStoneEvent(Object event, BlockPos b);
}
