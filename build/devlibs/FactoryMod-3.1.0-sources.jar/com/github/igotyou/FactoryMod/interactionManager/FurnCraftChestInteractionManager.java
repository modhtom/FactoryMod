package com.github.igotyou.FactoryMod.interactionManager;

import com.github.igotyou.FactoryMod.factories.Factory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class FurnCraftChestInteractionManager implements IInteractionManager {
    private Factory factory;

    public FurnCraftChestInteractionManager(Factory factory) { this.factory = factory; }
    public FurnCraftChestInteractionManager() {}
    public void setFactory(Factory factory) { this.factory = factory; }

    public void leftClick(ServerPlayerEntity p, BlockPos b, BlockState state, Direction face) {}
    public void rightClick(ServerPlayerEntity p, BlockPos b, BlockState state, Direction face) {}
    public void blockBreak(ServerPlayerEntity p, BlockPos b) {}
    public void redStoneEvent(Object event, BlockPos b) {}
}
