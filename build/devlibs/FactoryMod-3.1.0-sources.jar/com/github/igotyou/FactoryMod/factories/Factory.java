package com.github.igotyou.FactoryMod.factories;

import com.github.igotyou.FactoryMod.interactionManager.IInteractionManager;
import com.github.igotyou.FactoryMod.structures.MultiBlockStructure;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

public abstract class Factory implements Runnable {

    protected IInteractionManager im;
    protected MultiBlockStructure mbs;
    protected boolean active;
    protected int updateTime;
    protected String name;
    protected int threadId = -1;

    public Factory(IInteractionManager im, MultiBlockStructure mbs, int updateTime, String name) {
        this.im = im;
        this.mbs = mbs;
        this.updateTime = updateTime;
        this.name = name;
    }

    // Legacy constructor for stubs
    public Factory(String name, MultiBlockStructure mbs, int updateTime) {
        this.name = name;
        this.mbs = mbs;
        this.updateTime = updateTime;
    }

    public String getName() { return name; }
    public MultiBlockStructure getMultiBlockStructure() { return mbs; }
    public boolean isActive() { return active; }
    public int getUpdateTime() { return updateTime; }
    public void deactivate() { active = false; }

    public abstract void attemptToActivate(ServerPlayerEntity p, boolean onStartUp);

    public void scheduleUpdate() {
        threadId = com.github.igotyou.FactoryMod.utility.TaskScheduler.scheduleSyncDelayedTask(this, getUpdateTime());
    }

    public void turnFurnaceOn(ServerWorld world, BlockPos pos) {
        if (world.getBlockEntity(pos) instanceof FurnaceBlockEntity furnace) {
            furnace.markDirty();
        }
    }

    public void turnFurnaceOff(ServerWorld world, BlockPos pos) {
        if (world.getBlockEntity(pos) instanceof FurnaceBlockEntity furnace) {
            furnace.markDirty();
        }
    }

    public String getLogData() {
        return name + " at " + (mbs != null ? mbs.getCenter() : "unknown");
    }

    public IInteractionManager getInteractionManager() { return im; }
    // getRepairManager() stubbed - repair system to be reimplemented
    public Object getRepairManager() { return null; }

    @Override
    public void run() {}
}

