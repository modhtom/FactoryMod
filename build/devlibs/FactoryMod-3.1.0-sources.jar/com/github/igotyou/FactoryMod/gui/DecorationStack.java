package com.github.igotyou.FactoryMod.gui;

import net.minecraft.item.ItemStack;

public class DecorationStack extends Clickable {
    public DecorationStack(ItemStack item) {
        super(item);
    }
}
