package com.github.igotyou.FactoryMod.gui;

import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public class Clickable implements IClickable {
    protected ItemStack item;
    
    public Clickable(ItemStack item) {
        this.item = item;
    }
    
    @Override
    public ItemStack getItemStack() {
        return item;
    }
    
    @Override
    public void clicked(ServerPlayerEntity p) {
        // Mock default implementation
    }
    
    protected void onRightClick(ServerPlayerEntity p) {}
    protected void onShiftRightClick(ServerPlayerEntity p) {}
    protected void onDoubleClick(ServerPlayerEntity p) {}
    
    @Override
    public void addedToInventory(ClickableInventory inv, int slot) {}
}
