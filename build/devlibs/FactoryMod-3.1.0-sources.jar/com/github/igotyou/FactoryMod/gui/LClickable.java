package com.github.igotyou.FactoryMod.gui;

import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.function.Consumer;

public class LClickable extends Clickable {
    private Consumer<ServerPlayerEntity> action;
    
    public LClickable(ItemStack item, Consumer<ServerPlayerEntity> action) {
        super(item);
        this.action = action;
    }
    
    public LClickable(ItemStack item, String name, Consumer<ServerPlayerEntity> action) {
        super(item);
        this.action = action;
    }

    public LClickable(net.minecraft.item.Item item, String name, Consumer<ServerPlayerEntity> action) {
        super(new ItemStack(item));
        this.action = action;
    }
    
    @Override
    public void clicked(ServerPlayerEntity p) {
        if (action != null) {
            action.accept(p);
        }
    }
}
