package com.github.igotyou.FactoryMod.gui;

import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public interface IClickable {
    ItemStack getItemStack();
    void clicked(ServerPlayerEntity p);
    void addedToInventory(ClickableInventory inv, int slot);
}
