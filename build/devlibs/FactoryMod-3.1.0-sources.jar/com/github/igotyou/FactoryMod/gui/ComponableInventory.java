package com.github.igotyou.FactoryMod.gui;

import net.minecraft.server.network.ServerPlayerEntity;

public class ComponableInventory {
    public ComponableInventory(String name, int rows, ServerPlayerEntity player) {}
    
    public void addComponent(InventoryComponent component, Object slotPredicate) {}
    public void removeComponent(InventoryComponent component) {}
    public void clear() {}
    public void show() {}
    public void update() {}
    public void updatePlayerView() {}
}
