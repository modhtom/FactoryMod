package com.github.igotyou.FactoryMod.events;
import com.github.igotyou.FactoryMod.factories.Factory;
import net.minecraft.server.network.ServerPlayerEntity;
public class FactoryActivateEvent {
    public FactoryActivateEvent(Factory f, ServerPlayerEntity p) {}
    public boolean isCancelled() { return false; }
    public void setCancelled(boolean c) {}
}
