package com.github.igotyou.FactoryMod;




import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FactoryMod implements ModInitializer {

    private FactoryModManager manager;
    private static FactoryMod plugin;
    
    private static final Logger LOGGER = LoggerFactory.getLogger("FactoryMod");

    @Override
    public void onInitialize() {
        plugin = this;
        ConfigParser cp = new ConfigParser(this);
        com.github.igotyou.FactoryMod.utility.TaskScheduler.init();
        manager = new FactoryModManager(this, null, false, false, 0, 0, false, 0, 0, 0, 0, null, false);
        manager.loadFactories();
        
        
        registerListeners();
        LOGGER.info("FactoryMod successfully enabled");
    }

    public void onDisable() {
        if (manager != null) {
            manager.shutDown();
        }
        LOGGER.info("FactoryMod shutting down");
    }

    public FactoryModManager getManager() {
        return manager;
    }

    public static FactoryMod getInstance() {
        return plugin;
    }

    public static Logger getLogger() {
        return LOGGER;
    }

    public void info(String message) {
        LOGGER.info(message);
    }
    
    public void warning(String message) {
        LOGGER.warn(message);
    }
    
    public void severe(String message) {
        LOGGER.error(message);
    }

    private void registerListeners() {
        
        
    }
}
