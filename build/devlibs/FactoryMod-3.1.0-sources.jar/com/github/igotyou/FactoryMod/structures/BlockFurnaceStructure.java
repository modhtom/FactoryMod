package com.github.igotyou.FactoryMod.structures;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Blocks;
import java.util.List;
import java.util.ArrayList;

public class BlockFurnaceStructure extends MultiBlockStructure { 
    private BlockPos furnace;
    private boolean complete;

    public BlockFurnaceStructure(ServerWorld world, BlockPos center) { 
        super(world);
        if (world.getBlockState(center).isOf(Blocks.FURNACE)) {
            this.furnace = center;
        }
        this.complete = this.furnace != null;
    } 

    public BlockFurnaceStructure(ServerWorld world, List<BlockPos> blocks) {
        super(world);
        this.furnace = blocks.get(0);
        recheckComplete();
    }

    public void recheckComplete() {
        this.complete = furnace != null && world.getBlockState(furnace).isOf(Blocks.FURNACE);
    } 
    
    public boolean isComplete() { return complete; } 
    public BlockPos getCenter() { return furnace; } 
    public BlockPos getFurnace() { return furnace; }
    
    public List<BlockPos> getAllBlocks() { 
        List<BlockPos> list = new ArrayList<>();
        list.add(furnace);
        return list;
    } 
    
    public List<BlockPos> getRelevantBlocks() { return getAllBlocks(); } 
}
