package com.github.igotyou.FactoryMod.structures;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import java.util.List;
import java.util.ArrayList;

public class FurnCraftChestStructure extends MultiBlockStructure { 
    private BlockPos craftingTable;
    private BlockPos furnace;
    private BlockPos chest;
    private boolean complete;

    public FurnCraftChestStructure(ServerWorld world, BlockPos center) { 
        super(world);
        if (world.getBlockState(center).isOf(Blocks.CRAFTING_TABLE)) {
            this.craftingTable = center;
            List<BlockPos> chestBlocks = new ArrayList<>();
            for (Direction d : Direction.values()) {
                BlockState s = world.getBlockState(center.offset(d));
                if (s.isOf(Blocks.CHEST) || s.isOf(Blocks.TRAPPED_CHEST) || s.isOf(Blocks.BARREL)) {
                    chestBlocks.add(center.offset(d));
                }
            }
            
            for (BlockPos b : chestBlocks) {
                // Find face from center to b
                Direction chestFace = null;
                for (Direction d : Direction.values()) {
                    if (center.offset(d).equals(b)) {
                        chestFace = d; break;
                    }
                }
                if (chestFace == null) continue;
                Direction furnaceFace = chestFace.getOpposite();
                BlockPos furnaceBlock = center.offset(furnaceFace);
                if (world.getBlockState(furnaceBlock).isOf(Blocks.FURNACE)) {
                    this.chest = b;
                    this.furnace = furnaceBlock;
                    break;
                }
            }
        }
        this.complete = this.chest != null && this.furnace != null;
    } 

    public FurnCraftChestStructure(ServerWorld world, List<BlockPos> blocks) {
        super(world);
        this.craftingTable = blocks.get(0);
        this.furnace = blocks.get(1);
        this.chest = blocks.get(2);
        recheckComplete();
    }

    public void recheckComplete() { 
        this.complete = craftingTable != null && world.getBlockState(craftingTable).isOf(Blocks.CRAFTING_TABLE)
                     && furnace != null && world.getBlockState(furnace).isOf(Blocks.FURNACE)
                     && chest != null && (world.getBlockState(chest).isOf(Blocks.CHEST) || world.getBlockState(chest).isOf(Blocks.TRAPPED_CHEST) || world.getBlockState(chest).isOf(Blocks.BARREL));
    } 
    
    public boolean isComplete() { return complete; } 
    public BlockPos getCenter() { return craftingTable; } 
    
    public List<BlockPos> getAllBlocks() { 
        List<BlockPos> list = new ArrayList<>();
        list.add(craftingTable); list.add(furnace); list.add(chest);
        return list;
    } 
    
    public List<BlockPos> getRelevantBlocks() { 
        return getAllBlocks();
    }
    
    public BlockPos getCraftingTable() { return craftingTable; }
    public BlockPos getFurnace() { return furnace; }
    public BlockPos getChest() { return chest; }
}
