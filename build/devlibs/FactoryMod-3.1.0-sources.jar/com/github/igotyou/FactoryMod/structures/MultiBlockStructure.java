package com.github.igotyou.FactoryMod.structures;

import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.server.world.ServerWorld;
import java.util.List;
import java.util.LinkedList;

public abstract class MultiBlockStructure {
    protected ServerWorld world;
    
    public MultiBlockStructure(ServerWorld world) {
        this.world = world;
    }

    public ServerWorld getWorld() { return world; }

    public abstract List<BlockPos> getRelevantBlocks();
    public abstract List<BlockPos> getAllBlocks();
    public abstract BlockPos getCenter();
    public abstract boolean isComplete();
    public abstract void recheckComplete();

    public static boolean isBlockDirectlyConnectedTo(ServerWorld world, BlockPos b, Item m) { 
        for (Direction d : Direction.values()) {
            if (world.getBlockState(b.offset(d)).isOf(net.minecraft.block.Block.getBlockFromItem(m))) return true;
        }
        return false; 
    }
    
    public static boolean isBlockDirectlyConnectedTo(ServerWorld world, BlockPos b, Item m, Direction blockedFace) { 
        for (Direction d : Direction.values()) {
            if (d == blockedFace) continue;
            if (world.getBlockState(b.offset(d)).isOf(net.minecraft.block.Block.getBlockFromItem(m))) return true;
        }
        return false; 
    }
    
    public static List<BlockPos> getAdjacentBlocks(BlockPos b) { 
        List<BlockPos> result = new LinkedList<>();
        for (Direction d : Direction.values()) {
            result.add(b.offset(d));
        }
        return result; 
    }
    
    public static boolean insecureRedstone(ServerWorld world, BlockPos here) { 
        // We'll leave this false for now
        return false; 
    }
    
    public boolean blockedByExistingFactory() { 
        // Need integration with FactoryModManager to check this properly, stub for now
        return false; 
    }
    
    public boolean isCompletelyDestroyed() { 
        return !isComplete(); 
    }
}
