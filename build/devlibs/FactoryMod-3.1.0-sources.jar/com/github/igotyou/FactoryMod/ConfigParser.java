package com.github.igotyou.FactoryMod;
public class ConfigParser {
    private FactoryMod plugin;
    public ConfigParser(FactoryMod plugin) {
        this.plugin = plugin;
    }
    public FactoryModManager parse() { return null; }
}
