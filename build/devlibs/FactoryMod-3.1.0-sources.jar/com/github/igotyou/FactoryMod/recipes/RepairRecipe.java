package com.github.igotyou.FactoryMod.recipes;

import com.github.igotyou.FactoryMod.factories.Factory;
import com.github.igotyou.FactoryMod.utility.ItemMap;
import com.github.igotyou.FactoryMod.utility.ItemUtils;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class RepairRecipe extends InputRecipe {

    private int healthPerRun;

    public RepairRecipe(String identifier, String name, int productionTime, ItemMap input,
                        int healthPerRun) {
        super(identifier, name, productionTime, input);
        this.healthPerRun = healthPerRun;
    }

    @Override
    public List<ItemStack> getOutputRepresentation(Inventory i, Factory fccf) {
        List<ItemStack> result = new LinkedList<>();
        ItemStack furn = new ItemStack(Items.FURNACE);
        ItemUtils.setLore(furn, "+" + healthPerRun + " health");
        result.add(furn);
        return result;
    }

    @Override
    public boolean applyEffect(Inventory inputInv, Inventory outputInv, Factory fccf) {
        if (enoughMaterialAvailable(inputInv)) {
            if (input.removeSafelyFrom(inputInv)) {
                // Here we would call fccf repair logic, which requires repair manager
                // Assuming it might be stubbed out or will be updated:
                // ((PercentageHealthRepairManager) (fccf.getRepairManager())).repair(healthPerRun);
            }
            return true;
        }
        return false;
    }
    
    @Override
    public boolean enoughMaterialAvailable(Inventory inputInv) {
        ItemMap inMap = new ItemMap();
        for(int i=0; i<inputInv.size(); i++) {
             inMap.addItemStack(inputInv.getStack(i));
        }
        return input.isContainedIn(inMap);
    }

    @Override
    public String getTypeIdentifier() {
        return "REPAIR";
    }

    public int getHealth() {
        return healthPerRun;
    }

    @Override
    public List<String> getTextualOutputRepresentation(Inventory i, Factory fccf) {
        return Arrays.asList("Repairs the factory by " + healthPerRun + " health");
    }

    public EffectFeasibility evaluateEffectFeasibility(Inventory inputInv, Inventory outputInv, Factory fccf) {
        return new EffectFeasibility(enoughMaterialAvailable(inputInv), "");
    }
    
    public ItemStack getRecipeRepresentation() {
        return new ItemStack(Items.FURNACE);
    }
    
    public List<ItemStack> getInputRepresentation(Inventory i, Factory r) {
        List<ItemStack> res = new ArrayList<>();
        res.addAll(input.getItemStackRepresentation());
        return res;
    }
}
