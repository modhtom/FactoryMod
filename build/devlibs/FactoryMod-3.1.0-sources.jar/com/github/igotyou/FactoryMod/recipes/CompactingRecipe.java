package com.github.igotyou.FactoryMod.recipes;

import com.github.igotyou.FactoryMod.FactoryMod;
import com.github.igotyou.FactoryMod.factories.Factory;
import com.github.igotyou.FactoryMod.utility.ItemMap;
import com.github.igotyou.FactoryMod.utility.ItemUtils;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class CompactingRecipe extends InputRecipe {

    private List<Item> excludedMaterials;
    private String compactedLore;

    public CompactingRecipe(String identifier, ItemMap input, List<Item> excludedMaterial,
                            String name, int productionTime, String compactedLore) {
        super(identifier, name, productionTime, input);
        this.excludedMaterials = excludedMaterial;
        this.compactedLore = compactedLore;
    }

    private ItemMap getMap(Inventory inv) {
        ItemMap map = new ItemMap();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack != null && !stack.isEmpty()) {
                map.addItemStack(stack);
            }
        }
        return map;
    }

    @Override
    public boolean enoughMaterialAvailable(Inventory inputInv) {
        if (!input.isContainedIn(getMap(inputInv))) {
            return false;
        }
        ItemMap im = getMap(inputInv);
        for (int i = 0; i < inputInv.size(); i++) {
            ItemStack is = inputInv.getStack(i);
            if (is != null && !is.isEmpty()) {
                if (compactable(is, im)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean applyEffect(Inventory inputInv, Inventory outputInv, Factory fccf) {
        if (input.isContainedIn(getMap(inputInv))) {
            ItemMap im = getMap(inputInv);
            for (int i = 0; i < inputInv.size(); i++) {
                ItemStack is = inputInv.getStack(i);
                if (is != null && !is.isEmpty()) {
                    if (compactable(is, im)) {
                        ItemStack compacted = is.copy();
                        compactStack(compacted);
                        // We should test if it fits in outputInv
                        // But simplified:
                        if (input.removeSafelyFrom(inputInv)) {
                            compact(is, inputInv, outputInv);
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    @Override
    public List<ItemStack> getOutputRepresentation(Inventory i, Factory fccf) {
        List<ItemStack> result = new LinkedList<>();
        if (i == null) {
            ItemStack is = new ItemStack(Items.STONE, 64);
            compactStack(is);
            result.add(is);
            return result;
        }
        ItemMap im = getMap(i);
        for (int j = 0; j < i.size(); j++) {
            ItemStack is = i.getStack(j);
            if (is != null && !is.isEmpty()) {
                if (compactable(is, im)) {
                    ItemStack decompactedStack = is.copy();
                    compactStack(decompactedStack);
                    result.add(decompactedStack);
                    break;
                }
            }
        }
        return result;
    }

    public Item getRecipeRepresentationMaterial() {
        return Items.CHEST;
    }

    private void compact(ItemStack is, Inventory inputInv, Inventory outputInv) {
        ItemStack copy = is.copy();
        copy.setCount(getCompactStackSize(copy));
        ItemMap toRemove = new ItemMap(copy);
        if (toRemove.removeSafelyFrom(inputInv)) {
            compactStack(copy);
            // find empty slot in output or merge
            for(int j=0; j<outputInv.size(); j++) {
                ItemStack outSlot = outputInv.getStack(j);
                if(outSlot.isEmpty()) {
                    outputInv.setStack(j, copy);
                    break;
                } else if(ItemStack.areItemsAndComponentsEqual(outSlot, copy)) {
                    int canAdd = Math.min(copy.getCount(), outSlot.getMaxCount() - outSlot.getCount());
                    if(canAdd > 0) {
                        outSlot.increment(canAdd);
                        copy.decrement(canAdd);
                        if(copy.isEmpty()) break;
                    }
                }
            }
        }
    }

    private void compactStack(ItemStack is) {
        ItemUtils.addLore(is, compactedLore);
        is.setCount(1);
    }

    public static int getCompactStackSize(ItemStack m) {
        int max = m.getMaxCount();
        if (max == 64) return 64;
        if (max == 16 || max == 2) return 16;
        if (max == 1) return 8;
        return 999_999; 
    }

    private boolean compactable(ItemStack is, ItemMap im) {
        if (is == null || is.isEmpty() || excludedMaterials.contains(is.getItem()) || (input.getAmount(is.getItem()) != 0)) {
            return false;
        }
        net.minecraft.component.type.LoreComponent lore = is.get(net.minecraft.component.DataComponentTypes.LORE);
        if (lore != null) {
            for (net.minecraft.text.Text line : lore.lines()) {
                if (line.getString().contains(compactedLore)) {
                    return false;
                }
            }
        }
        // Simplified Shulker/bundle check, just assume max stack size check
        return im.getAmount(is.getItem()) >= getCompactStackSize(is);
    }

    @Override
    public String getTypeIdentifier() {
        return "COMPACT";
    }

    public String getCompactedLore() {
        return compactedLore;
    }

    public List<Item> getExcludedMaterials() {
        return excludedMaterials;
    }
    
    @Override
    public List<String> getTextualOutputRepresentation(Inventory i, Factory fccf) {
        return Arrays.asList("Input stack compacted into a single item");
    }

    public EffectFeasibility evaluateEffectFeasibility(Inventory inputInv, Inventory outputInv, Factory fccf) {
        return new EffectFeasibility(enoughMaterialAvailable(inputInv), "");
    }
    
    public ItemStack getRecipeRepresentation() {
        return new ItemStack(Items.CHEST);
    }
    
    public List<ItemStack> getInputRepresentation(Inventory i, Factory r) {
        List<ItemStack> res = new ArrayList<>();
        res.addAll(input.getItemStackRepresentation());
        return res;
    }
}
