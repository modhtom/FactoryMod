package com.github.igotyou.FactoryMod.recipes;

import com.github.igotyou.FactoryMod.factories.Factory;
import com.github.igotyou.FactoryMod.utility.ItemMap;
import com.github.igotyou.FactoryMod.utility.ItemUtils;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

public class PylonRecipe extends InputRecipe {

    private ItemMap output;
    private static int currentGlobalWeight;
    private static int globalLimit;
    private int weight;

    public PylonRecipe(String identifier, String name, int productionTime, ItemMap input,
                       ItemMap output, int weight) {
        super(identifier, name, productionTime, input);
        this.output = output;
        this.weight = weight;
    }

    @Override
    public boolean applyEffect(Inventory inputInv, Inventory outputInv, Factory fccf) {
        ItemMap inMap = new ItemMap();
        for(int i=0; i<inputInv.size(); i++) {
             inMap.addItemStack(inputInv.getStack(i));
        }
        if (!input.isContainedIn(inMap)) {
            return false;
        }
        ItemMap actualOutput = getCurrentOutput();
        if (input.removeSafelyFrom(inputInv)) {
            for (ItemStack is : actualOutput.getItemStackRepresentation()) {
                for(int j=0; j<outputInv.size(); j++) {
                    ItemStack outSlot = outputInv.getStack(j);
                    if(outSlot.isEmpty()) {
                        outputInv.setStack(j, is.copy());
                        break;
                    } else if(ItemStack.areItemsAndComponentsEqual(outSlot, is)) {
                        int canAdd = Math.min(is.getCount(), outSlot.getMaxCount() - outSlot.getCount());
                        if(canAdd > 0) {
                            outSlot.increment(canAdd);
                            is.decrement(canAdd);
                            if(is.isEmpty()) break;
                        }
                    }
                }
            }
        }
        return true;
    }

    public static void setGlobalLimit(int limit) {
        globalLimit = limit;
    }

    public static int getGlobalLimit() {
        return globalLimit;
    }

    @Override
    public List<ItemStack> getOutputRepresentation(Inventory i, Factory fccf) {
        ItemMap currOut = getCurrentOutput();
        List<ItemStack> res = new LinkedList<>();
        for (ItemStack is : currOut.getItemStackRepresentation()) {
            ItemUtils.setLore(is, "Pylon factory item", "Current global weight: " + currentGlobalWeight);
            res.add(is);
        }
        return res;
    }

    @Override
    public boolean enoughMaterialAvailable(Inventory inputInv) {
        ItemMap inMap = new ItemMap();
        for(int i=0; i<inputInv.size(); i++) {
             inMap.addItemStack(inputInv.getStack(i));
        }
        return input.isContainedIn(inMap);
    }

    public int getWeight() {
        return weight;
    }

    private ItemMap getCurrentOutput() {
        double overload = Math.max(1.0, (float) currentGlobalWeight / (float) (globalLimit > 0 ? globalLimit : 1));
        double multiplier = 1.0 / overload;
        ItemMap actualOutput = new ItemMap();
        for (Entry<Item, Integer> entry : output.getAllItems().entrySet()) {
            actualOutput.addItemAmount(entry.getKey(), (int) (entry.getValue() * multiplier));
        }
        return actualOutput;
    }

    public static void addWeight(int weight) {
        currentGlobalWeight += weight;
    }

    public static void removeWeight(int weight) {
        currentGlobalWeight -= weight;
    }

    @Override
    public String getTypeIdentifier() {
        return "PYLON";
    }

    public ItemMap getOutput() {
        return output;
    }

    @Override
    public List<String> getTextualOutputRepresentation(Inventory i, Factory fccf) {
        List<String> result = new ArrayList<>();
        for (Entry<Item, Integer> entry : output.getAllItems().entrySet()) {
            if (entry.getValue() > 0) {
                result.add(entry.getValue() + " " + entry.getKey().getName().getString());
            }
        }
        return result;
    }

    public EffectFeasibility evaluateEffectFeasibility(Inventory inputInv, Inventory outputInv, Factory fccf) {
        return new EffectFeasibility(enoughMaterialAvailable(inputInv), "");
    }
    
    public ItemStack getRecipeRepresentation() {
        if(!output.getItemStackRepresentation().isEmpty())
            return output.getItemStackRepresentation().iterator().next().copy();
        return new ItemStack(net.minecraft.item.Items.BEACON);
    }
    
    public List<ItemStack> getInputRepresentation(Inventory i, Factory r) {
        List<ItemStack> res = new ArrayList<>();
        res.addAll(input.getItemStackRepresentation());
        return res;
    }
}
