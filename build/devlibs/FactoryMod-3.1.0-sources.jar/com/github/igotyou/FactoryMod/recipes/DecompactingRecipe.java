package com.github.igotyou.FactoryMod.recipes;

import com.github.igotyou.FactoryMod.factories.Factory;
import com.github.igotyou.FactoryMod.utility.ItemMap;
import com.github.igotyou.FactoryMod.utility.ItemUtils;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class DecompactingRecipe extends InputRecipe {

    private final String compactedLore;

    public DecompactingRecipe(String identifier, ItemMap input, String name, int productionTime,
                              String compactedLore) {
        super(identifier, name, productionTime, input);
        this.compactedLore = compactedLore;
    }

    @Override
    public boolean enoughMaterialAvailable(Inventory inputInv) {
        ItemMap inputMap = new ItemMap();
        for(int i=0; i<inputInv.size(); i++) {
            inputMap.addItemStack(inputInv.getStack(i));
        }
        if (!input.isContainedIn(inputMap)) {
            return false;
        }
        for (int i = 0; i < inputInv.size(); i++) {
            ItemStack is = inputInv.getStack(i);
            if (is != null && !is.isEmpty()) {
                if (isDecompactable(is)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public EffectFeasibility evaluateEffectFeasibility(Inventory inputInv, Inventory outputInv, Factory fccf) {
        boolean isFeasible = true;
        return new EffectFeasibility(
            isFeasible,
            isFeasible ? null : "it ran out of storage space"
        );
    }

    @Override
    public boolean applyEffect(Inventory inputInv, Inventory outputInv, Factory fccf) {
        ItemMap inputMap = new ItemMap();
        for(int i=0; i<inputInv.size(); i++) {
            inputMap.addItemStack(inputInv.getStack(i));
        }
        if (input.isContainedIn(inputMap)) {
            for (int i=0; i < inputInv.size(); i++) {
                ItemStack is = inputInv.getStack(i);
                if (is != null && !is.isEmpty()) {
                    if (isDecompactable(is)) {
                        ItemStack removeClone = is.copy();
                        removeClone.setCount(1);
                        ItemMap toRemove = new ItemMap(removeClone);
                        ItemMap toAdd = new ItemMap();
                        removeCompactLore(removeClone);
                        toAdd.addItemAmount(removeClone.getItem(), CompactingRecipe.getCompactStackSize(removeClone));
                        if (input.removeSafelyFrom(inputInv)) {
                            if (toRemove.removeSafelyFrom(inputInv)) {
                                for (ItemStack add : toAdd.getItemStackRepresentation()) {
                                    for(int j=0; j<outputInv.size(); j++) {
                                        ItemStack outSlot = outputInv.getStack(j);
                                        if(outSlot.isEmpty()) {
                                            outputInv.setStack(j, add.copy());
                                            break;
                                        } else if(ItemStack.areItemsAndComponentsEqual(outSlot, add)) {
                                            int canAdd = Math.min(add.getCount(), outSlot.getMaxCount() - outSlot.getCount());
                                            if(canAdd > 0) {
                                                outSlot.increment(canAdd);
                                                add.decrement(canAdd);
                                                if(add.isEmpty()) break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public List<ItemStack> getOutputRepresentation(Inventory i, Factory fccf) {
        List<ItemStack> result = new LinkedList<>();
        if (i == null) {
            result.add(new ItemStack(Items.STONE, 64));
            return result;
        }
        for (int j=0; j<i.size(); j++) {
            ItemStack is = i.getStack(j);
            if (is != null && !is.isEmpty()) {
                if (isDecompactable(is)) {
                    ItemStack copy = is.copy();
                    removeCompactLore(copy);
                    ItemMap output = new ItemMap();
                    output.addItemAmount(copy.getItem(), CompactingRecipe.getCompactStackSize(copy));
                    result.addAll(output.getItemStackRepresentation());
                }
            }
        }
        return result;
    }

    private boolean isDecompactable(ItemStack is) {
        net.minecraft.component.type.LoreComponent lore = is.get(net.minecraft.component.DataComponentTypes.LORE);
        if (lore != null) {
            for (net.minecraft.text.Text line : lore.lines()) {
                if (line.getString().contains(compactedLore)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void removeCompactLore(ItemStack is) {
        // Simplified lore removal: just reset lore for decompaction since it is just compacted material
        is.remove(net.minecraft.component.DataComponentTypes.LORE);
    }

    @Override
    public String getTypeIdentifier() {
        return "DECOMPACT";
    }

    public String getCompactedLore() {
        return compactedLore;
    }

    @Override
    public List<String> getTextualOutputRepresentation(Inventory i, Factory fccf) {
        return Arrays.asList("An entire stack of the decompacted item if it's stackable", "---OR---", "Eight of the decompacted item if it's not stackable");
    }
    
    public ItemStack getRecipeRepresentation() {
        return new ItemStack(Items.TRAPPED_CHEST);
    }
    
    public List<ItemStack> getInputRepresentation(Inventory i, Factory r) {
        List<ItemStack> res = new ArrayList<>();
        res.addAll(input.getItemStackRepresentation());
        return res;
    }
}
