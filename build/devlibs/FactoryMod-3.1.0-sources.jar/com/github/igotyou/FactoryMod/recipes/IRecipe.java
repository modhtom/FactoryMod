package com.github.igotyou.FactoryMod.recipes;
import net.minecraft.inventory.Inventory;
import com.github.igotyou.FactoryMod.factories.Factory;
import net.minecraft.item.ItemStack;
import java.util.List;

public interface IRecipe {
    String getName();
    String getIdentifier();
    int getProductionTime();
    default int getProductionTime(Factory fccf) { return getProductionTime(); }
    boolean enoughMaterialAvailable(Inventory inputInv);
    default EffectFeasibility evaluateEffectFeasibility(Inventory inputInv, Inventory outputInv, Factory fccf) { return new EffectFeasibility(true, null); }
    boolean applyEffect(Inventory inputInv, Inventory outputInv, Factory fccf);
    String getTypeIdentifier();
    default boolean canApplySpeed() { return true; }
    default boolean mustBeLoaded() { return false; }
}
