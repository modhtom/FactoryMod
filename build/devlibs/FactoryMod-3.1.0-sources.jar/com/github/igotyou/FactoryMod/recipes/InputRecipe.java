package com.github.igotyou.FactoryMod.recipes;

import net.minecraft.inventory.Inventory;
import com.github.igotyou.FactoryMod.factories.Factory;
import com.github.igotyou.FactoryMod.utility.ItemMap;
import net.minecraft.item.ItemStack;
import java.util.List;
import java.util.ArrayList;

public abstract class InputRecipe implements IRecipe {
    protected String name;
    protected String identifier;
    protected int productionTime;
    protected ItemMap input;

    public InputRecipe(String identifier, String name, int productionTime, ItemMap input) {
        this.identifier = identifier;
        this.name = name;
        this.productionTime = productionTime;
        this.input = input;
    }

    public String getIdentifier() { return identifier; }
    public String getName() { return name; }
    public int getProductionTime() { return productionTime; }
    public ItemMap getInput() { return input; }

    // Check by scanning slots without mutating inventory
    public boolean enoughMaterialAvailable(Inventory inv) {
        ItemMap have = new ItemMap();
        for (int i = 0; i < inv.size(); i++) {
            have.addItemStack(inv.getStack(i));
        }
        return input.isContainedIn(have);
    }

    // These must be declared here so subclasses that override them have the right signature.
    public abstract List<ItemStack> getOutputRepresentation(Inventory i, Factory fccf);
    public abstract List<String> getTextualOutputRepresentation(Inventory i, Factory fccf);

    // Needed by IRecipe; concrete subclasses may override
    public List<ItemStack> getInputRepresentation(Inventory i, IRecipe r) { 
        return new ArrayList<>(input.getItemStackRepresentation());
    }
    public ItemStack getRecipeRepresentation() { return null; }
}
